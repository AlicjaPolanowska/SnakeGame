from setuptools import setup

setup(
    name = 'snake',
    version = '1.0',
    description = 'Engine for The Snake Game',
    author = 'Alicja Polanowska',
    py_modules= ['snake'],
    )
